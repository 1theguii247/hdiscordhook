package io.github.h1elzz.discordhook.commands;

/**
 * sem começo.
 */

public class ComandoLink {
}
