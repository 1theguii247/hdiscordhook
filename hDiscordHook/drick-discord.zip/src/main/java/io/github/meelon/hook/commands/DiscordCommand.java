package io.github.meelon.hook.commands;

import io.github.meelon.hook.menus.MenuOpen;
import me.faststore.biielkts.player.Profile;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class DiscordCommand implements CommandExecutor {


    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String arg2, String[] args) {
        if(sender instanceof Player) {
            Player player = (Player) sender;
            Profile profile = Profile.getProfile(player.getName());
            new MenuOpen(profile);
        }
        return false;
    }
}
