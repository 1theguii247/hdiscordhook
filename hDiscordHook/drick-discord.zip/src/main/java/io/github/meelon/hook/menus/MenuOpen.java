package io.github.meelon.hook.menus;

import io.github.meelon.hook.menus.link.MenuLink;
import me.faststore.biielkts.Core;
import me.faststore.biielkts.libraries.menu.PlayerMenu;
import me.faststore.biielkts.player.Profile;
import me.faststore.biielkts.player.role.Role;
import me.faststore.biielkts.utils.BukkitUtils;
import me.faststore.biielkts.utils.enums.EnumSound;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

public class MenuOpen extends PlayerMenu {


    public MenuOpen(Profile profile) {
        super(profile.getPlayer(), "Conta de Discord", 3);

        setItem(11, BukkitUtils.putProfileOnSkull(this.player, BukkitUtils.deserializeItemStack("SKULL_ITEM:3 : 1 : nome>&aMinha Conta : desc>\n &fNickname: "+Role.getColored(profile.getName())+ "\n \n&eClique aqui pra vincular.")));

        setItem(15, BukkitUtils.deserializeItemStack("SKULL_ITEM:3 : 1 : nome>&aDiscord do servidor : desc>&7Clique para entrar no discord do servidor. : skin>eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNzg3M2MxMmJmZmI1MjUxYTBiODhkNWFlNzVjNzI0N2NiMzlhNzVmZjFhODFjYmU0YzhhMzliMzExZGRlZGEifX19"));

        setItem(13, BukkitUtils.deserializeItemStack("386 : 1 : nome>&6Ajuda : desc>&7Clique aqui para abrir o menu de ajuda!"));

        this.open();
        this.register(Core.getInstance());
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent evt) {
        if (evt.getInventory().equals(this.getInventory())) {
            evt.setCancelled(true);

            if (evt.getWhoClicked().equals(this.player)) {
                Profile profile = Profile.getProfile(this.player.getName());
                if (profile == null) {
                    player.closeInventory();
                    return;
                }

                if (evt.getClickedInventory() != null && evt.getClickedInventory().equals(this.getInventory())) {
                    ItemStack item = evt.getCurrentItem();

                    if (item != null && item.getType() != Material.AIR) {
                        if (evt.getSlot() == 15) {
                            EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                            this.player.sendMessage("\n ");
                            this.player.closeInventory();
                        } else if (evt.getSlot() == 11) {
                            EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                            new MenuLink(profile);
                        } else if (evt.getSlot() == 13) {
                            this.player.sendMessage("");
                            this.player.sendMessage("   §7Ajuda - Vincular");
                            this.player.sendMessage("");
                            this.player.sendMessage("§e/associar §7- §fVincule sua conta no servidor.");
                            this.player.sendMessage("§e/desassociar §7- §fRetirar o vinculo de sua conta.");
                            this.player.sendMessage("");


                        }
                    }
                }
            }
        }
    }

    public void cancel() {
        HandlerList.unregisterAll(this);
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent evt) {
        if (evt.getPlayer().equals(this.player)) {
            this.cancel();
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent evt) {
        if (evt.getPlayer().equals(this.player) && evt.getInventory().equals(this.getInventory())) {
            this.cancel();
        }
    }
}
