package io.github.meelon.hook;

import io.github.meelon.hook.commands.DiscordCommand;
import io.github.meelon.hook.commands.UnlinkCommand;
import io.github.meelon.hook.commands.VincularCommand;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public class Main extends JavaPlugin {

    public static Main instance;
    public static boolean DiscordSRV;


    @Override
    public void onLoad() {
       DiscordSRV = Bukkit.getPluginManager().getPlugin("DiscordSRV") != null;
       // puxando o plugin....
    }

    @Override
    public void onEnable() {
        this.getCommand("discord").setExecutor(new DiscordCommand());
        this.getCommand("associar").setExecutor(new VincularCommand());
        this.getCommand("desassociar").setExecutor(new UnlinkCommand());
        //
        Bukkit.getConsoleSender().sendMessage("");
        Bukkit.getConsoleSender().sendMessage("§6    DiscordSRV Hook v1.0");
        Bukkit.getConsoleSender().sendMessage("§6 Criador: ItsMeelon");
        Bukkit.getConsoleSender().sendMessage("");

    }

    @Override
    public void onDisable() {
        Bukkit.getConsoleSender().sendMessage("");
        Bukkit.getConsoleSender().sendMessage("§c      DiscordSRV Hook - Desativado.");
        Bukkit.getConsoleSender().sendMessage("");
    }


    public static Main getInstance() {
        return instance;
    }
}
