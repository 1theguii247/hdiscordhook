package io.github.meelon.hook.commands;

/**
 * sem começo.
 */

public class LinkCommand {
}
