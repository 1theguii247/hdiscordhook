package io.github.meelon.hook.commands;

import me.faststore.biielkts.player.Profile;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class VincularCommand implements CommandExecutor {


        @Override
        public boolean onCommand(CommandSender commandSender, Command command, String s, String[] strings) {
            if(command.getName().equalsIgnoreCase("associar") && (commandSender instanceof Player)) {
                Player player = (Player) commandSender;
                 player.chat("/discordsrv link");
                }
            return true;
        }
    }
